package textviewer;
/**
 * @author CS 442 / CS 542
 */
public interface Modifier {
	public Block[][] modify(Block[][] blocks, int width);
}
