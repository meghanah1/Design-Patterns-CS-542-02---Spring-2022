package hfmenuiterator;

import java.util.Iterator;
  
public class Server {
	MenuComponent allMenus;
 
	public Server(MenuComponent allMenus) {
		this.allMenus = allMenus;
	}
 
	public void printMenu() {
		allMenus.clearIterator();
		Iterator<MenuComponent> iterator = allMenus.createIterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
	}
  
	public void printVegetarianMenu() {
		allMenus.clearIterator();
		Iterator<MenuComponent> iterator = allMenus.createIterator();
		while (iterator.hasNext()) {
			MenuComponent mc = iterator.next();
			if(mc instanceof ListMenu ||
			(mc instanceof MenuItem && mc.isVegetarian())) 
				System.out.println(mc);
		}
	}
}
