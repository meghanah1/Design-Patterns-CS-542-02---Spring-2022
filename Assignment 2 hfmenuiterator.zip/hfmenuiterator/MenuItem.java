package hfmenuiterator;

import java.util.Iterator;

public class MenuItem extends MenuComponent {
 
	private String name;
	private String description;
	private boolean vegetarian;
	private double price;
    
	public MenuItem(String nameIn, 
	                String descriptionIn, 
	                boolean vegetarianIn, 
	                double priceIn) { 
		name = nameIn;
		description = descriptionIn;
		vegetarian = vegetarianIn;
		price = priceIn;
	}
  
	public String getName() {
		return name;
	}
  
	public String getDescription() {
		return description;
	}
  
	public double getPrice() {
		return price;
	}
  
	public boolean isVegetarian() {
		return vegetarian;
	}

	public Iterator<MenuComponent> createIterator() {
		return new NullIterator();
	}
 
	public String toString() {
		return "  " + getName() + (isVegetarian()?"(v)":"") + 
				", " + getPrice() + "\n" + "     -- " + 
				getDescription();
	}

}

